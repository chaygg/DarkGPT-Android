package com.darkgpt.chat;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9,11,16), PANEL = Color.rgb(21,25,35), BLUE = Color.rgb(255,45,45);
    private LinearLayout messages;
    private EditText input;
    private ScrollView scroll;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(1); root.setPadding(dp(16),dp(12),dp(16),dp(12)); root.setBackgroundColor(BG);

        TextView title = new TextView(this);
        title.setText("DarkGPT"); title.setTextColor(Color.WHITE); title.setTextSize(25);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(48)));

        TextView sub = new TextView(this);
        sub.setText("مساعدك الذكي"); sub.setTextColor(BLUE); sub.setTextSize(14);
        root.addView(sub,new LinearLayout.LayoutParams(-1,dp(28)));

        scroll = new ScrollView(this); scroll.setFillViewport(true);
        messages = new LinearLayout(this); messages.setOrientation(1); messages.setPadding(0,dp(8),0,dp(8));
        scroll.addView(messages); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8),dp(5),dp(5),dp(5));
        bar.setBackground(round(PANEL,18));
        input = new EditText(this); input.setHint("اكتب رسالتك..."); input.setSingleLine(false); input.setMaxLines(4);
        input.setTextColor(Color.WHITE); input.setHintTextColor(Color.GRAY); input.setTextSize(15);
        input.setBackgroundColor(Color.TRANSPARENT); input.setPadding(dp(8),dp(6),dp(8),dp(6));
        bar.addView(input,new LinearLayout.LayoutParams(0,-2,1));
        Button send = new Button(this); send.setText("إرسال"); send.setAllCaps(false); send.setTextColor(Color.WHITE); send.setBackground(round(BLUE,14));
        bar.addView(send,new LinearLayout.LayoutParams(-2,dp(46)));
        send.setOnClickListener(v -> sendMessage());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1,-2); bp.topMargin=dp(10); root.addView(bar,bp);
        setContentView(root);
        addMessage("DarkGPT","مرحبًا! الواجهة جاهزة. الردود حاليًا تجريبية محلية؛ لم يتم ربط خادم ذكاء اصطناعي بعد.",false);
    }

    private void sendMessage() {
        String text=input.getText().toString().trim(); if(text.isEmpty()) return;
        addMessage("أنت",text,true); input.setText("");
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);
        addMessage("DarkGPT","وصلت رسالتك. لتمكين الردود الذكية الحقيقية، اربط التطبيق بخادم HTTPS خاص بك.",false);
    }

    private void addMessage(String who,String body,boolean mine) {
        LinearLayout bubble=new LinearLayout(this); bubble.setOrientation(1); bubble.setPadding(dp(13),dp(10),dp(13),dp(10));
        bubble.setBackground(round(mine?Color.rgb(92,20,25):PANEL,16));
        TextView label=new TextView(this); label.setText(who); label.setTextColor(mine?Color.rgb(255,150,150):BLUE);
        label.setTypeface(Typeface.DEFAULT,Typeface.BOLD); label.setTextSize(12); bubble.addView(label);
        TextView msg=new TextView(this); msg.setText(body); msg.setTextColor(Color.WHITE); msg.setTextSize(15); msg.setTextIsSelectable(true);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,-2); mp.topMargin=dp(4); bubble.addView(msg,mp);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(8);
        p.leftMargin=mine?dp(34):0; p.rightMargin=mine?0:dp(34); messages.addView(bubble,p);
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private GradientDrawable round(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
}
